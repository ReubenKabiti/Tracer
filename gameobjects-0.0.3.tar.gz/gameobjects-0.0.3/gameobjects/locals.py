

( WRAP_REPEAT,
  WRAP_CLAMP,
  WRAP_ERROR ) = list(range(3))
